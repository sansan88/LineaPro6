cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.citronium.lineaprocdv.v2/www/LineaProCDV.js",
        "id": "com.citronium.lineaprocdv.v2.LineaProCDV",
        "clobbers": [
            "LineaProCDV"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.0.0",
    "com.citronium.lineaprocdv.v2": "0.1"
}
// BOTTOM OF METADATA
});